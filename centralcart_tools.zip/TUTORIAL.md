# CentralCart Tools — Tutorial
### by Yshin · @sunnerismylife

---

## Requisitos

- Android com **Termux** instalado
- Python instalado no Termux
- Conexão com a internet

---

## Instalação

**1. Instale o Python e o requests:**
```bash
pkg update && pkg install python
pip install requests
```

**2. Crie o script:**

Cole o conteúdo do arquivo `centralcart_tools.py` no Termux:
```bash
nano ~/centralcart_tools.py
```
Cole o código, salve com `Ctrl+X` → `Y` → `Enter`.

**3. Configure o token:**

Abra o script e troque `SEU_TOKEN_AQUI` pelo seu token da API:
```bash
nano ~/centralcart_tools.py
```
Encontre a linha:
```python
API_TOKEN = "SEU_TOKEN_AQUI"
```
Substitua pelo seu token real.

---

## Como rodar

```bash
python ~/centralcart_tools.py
```

Aparecerá um menu com as opções disponíveis:

```
╔══════════════════════════════════════════════════════╗
║         CentralCart Tools - by Yshin                ║
║              @sunnerismylife                         ║
╚══════════════════════════════════════════════════════╝

Escolha uma opção:
  1 - Migrar produtos de categoria
  2 - Atualizar preço comparativo (+70%)
  0 - Sair
```

---

## Opção 1 — Migrar produtos de categoria

Move todos os produtos de uma categoria para outra.

**Como usar:**
1. Selecione a opção `1`
2. Digite o slug da categoria de **origem** (ex: `jogos-simulacao`)
3. Digite o slug da categoria de **destino** (ex: `Steam`)
4. Aguarde o script processar todos os produtos

**Como encontrar o slug de uma categoria:**
```bash
curl -s "https://api.centralcart.com.br/v1/app/category" \
  -H "Authorization: Bearer SEU_TOKEN" | python -m json.tool | grep '"slug"'
```

---

## Opção 2 — Atualizar preço comparativo (+70%)

Atualiza o preço comparativo de todos os produtos (incluindo variações) para 70% acima do preço atual.

**Exemplo:** Produto R$10 → preço comparativo R$17

**Como usar:**
1. Selecione a opção `2`
2. Digite os slugs das categorias separados por vírgula, ou deixe em branco para processar **todas** as categorias
3. Aguarde o script processar

---

## Configurações avançadas

No topo do script você pode ajustar:

| Variável | Padrão | Descrição |
|---|---|---|
| `API_TOKEN` | — | Seu token da API CentralCart |
| `DELAY_ENTRE_REQUESTS` | `10` | Segundos entre cada requisição |
| `TAMANHO_PAGINA` | `50` | Produtos por página na listagem |

> **Dica:** Se alguns produtos não forem migrados, aumente o `DELAY_ENTRE_REQUESTS` para `15` ou `20`.

---

## Logs

Todos os scripts geram um arquivo de log na pasta home do Termux:
- `centralcart_tools.log` — log de todas as operações

Para visualizar:
```bash
cat ~/centralcart_tools.log
```

---

## Créditos

Desenvolvido por **Yshin** · [@sunnerismylife](https://instagram.com/sunnerismylife)

> Os créditos são protegidos e restaurados automaticamente caso removidos.

