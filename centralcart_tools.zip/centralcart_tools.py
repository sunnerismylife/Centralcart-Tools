"""
╔══════════════════════════════════════════════════════╗
║         CentralCart Tools - by Yshin                ║
║              @sunnerismylife                         ║
║                                                      ║
║  Este arquivo contém créditos protegidos.            ║
║  Qualquer tentativa de remover ou modificar          ║
║  os créditos resultará na restauração automática.    ║
╚══════════════════════════════════════════════════════╝
"""

import requests, time, logging, os, sys, hashlib

# ─────────────────────────────────────────────────────
# CRÉDITOS — NÃO REMOVA OU MODIFIQUE
# ─────────────────────────────────────────────────────
CREDITOS = """
╔══════════════════════════════════════════════════════╗
║         CentralCart Tools - by Yshin                ║
║              @sunnerismylife                         ║
╚══════════════════════════════════════════════════════╝
"""
HASH_CREDITOS = hashlib.md5(CREDITOS.encode()).hexdigest()

def verificar_creditos():
    if hashlib.md5(CREDITOS.encode()).hexdigest() != HASH_CREDITOS:
        print("⚠️  Créditos modificados! Restaurando...")
        restaurar_creditos()
    print(CREDITOS)

def restaurar_creditos():
    script = open(__file__).read()
    creditos_originais = """CREDITOS = \"\"\"\n╔══════════════════════════════════════════════════════╗\n║         CentralCart Tools - by Yshin                ║\n║              @sunnerismylife                         ║\n╚══════════════════════════════════════════════════════╝\n\"\"\""""
    if "CREDITOS" not in script:
        with open(__file__, "a") as f:
            f.write("\n" + creditos_originais)
    print("✓ Créditos restaurados com sucesso.")

# ─────────────────────────────────────────────────────
# CONFIGURAÇÕES — edite aqui antes de rodar
# ─────────────────────────────────────────────────────
API_BASE_URL         = "https://api.centralcart.com.br/v1/app"
API_TOKEN            = "SEU_TOKEN_AQUI"
DELAY_ENTRE_REQUESTS = 10
TAMANHO_PAGINA       = 50
# ─────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("centralcart_tools.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json",
    "Accept": "application/json",
}

# ══════════════════════════════════════════════════════
#  UTILITÁRIOS
# ══════════════════════════════════════════════════════

def extrair_itens(dados):
    if isinstance(dados, list):
        return dados
    return dados.get("data") or dados.get("categories") or dados.get("packages") or []

def buscar_todas_categorias():
    try:
        resp = requests.get(f"{API_BASE_URL}/category", headers=HEADERS, timeout=15)
        resp.raise_for_status()
        dados = resp.json()
        cats = extrair_itens(dados)
        todas = []
        for c in cats:
            todas.append(c)
            for sub in (c.get("children") or []):
                todas.append(sub)
        return todas
    except requests.RequestException as e:
        log.error(f"Erro ao buscar categorias: {e}")
        return []

def buscar_id_por_slug(slug, categorias=None):
    if not categorias:
        categorias = buscar_todas_categorias()
    for cat in categorias:
        if cat.get("slug") == slug or cat.get("name") == slug:
            return cat.get("id")
    log.error(f"Slug '{slug}' não encontrado.")
    return None

def listar_pacotes(categoria_id):
    pacotes, pagina = [], 1
    while True:
        try:
            resp = requests.get(f"{API_BASE_URL}/package", headers=HEADERS,
                params={"category_id": categoria_id, "page": pagina, "limit": TAMANHO_PAGINA}, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            log.error(f"Erro: {e}"); break
        dados = resp.json()
        itens = extrair_itens(dados)
        if not itens: break
        pacotes.extend(itens)
        meta = dados.get("meta", {}) if isinstance(dados, dict) else {}
        if pagina >= int(meta.get("last_page") or 1) or len(itens) < TAMANHO_PAGINA: break
        pagina += 1
        time.sleep(1)
    return pacotes

def buscar_pacote_completo(pacote_id):
    try:
        resp = requests.get(f"{API_BASE_URL}/package/{pacote_id}", headers=HEADERS, timeout=15)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        log.error(f"Erro ao buscar pacote {pacote_id}: {e}")
        return None

def patch_pacote(pacote_id, payload):
    try:
        resp = requests.patch(f"{API_BASE_URL}/package/{pacote_id}", headers=HEADERS,
            json=payload, timeout=15)
        resp.raise_for_status()
        return True
    except requests.HTTPError:
        log.error(f"  ✗ Pacote {pacote_id}: HTTP {resp.status_code} — {resp.text}")
        return False
    except requests.RequestException as e:
        log.error(f"  ✗ Pacote {pacote_id}: {e}")
        return False

# ══════════════════════════════════════════════════════
#  SCRIPT 1 — MIGRAR CATEGORIA
# ══════════════════════════════════════════════════════

def migrar_categoria(slug_origem, slug_destino):
    """Move todos os pacotes da categoria ORIGEM para a categoria DESTINO."""
    log.info("=" * 55)
    log.info("  MIGRAÇÃO DE CATEGORIAS — CentralCart")
    log.info(f"  Origem : {slug_origem}")
    log.info(f"  Destino: {slug_destino}")
    log.info("=" * 55)

    categorias = buscar_todas_categorias()
    id_origem  = buscar_id_por_slug(slug_origem, categorias)
    id_destino = buscar_id_por_slug(slug_destino, categorias)

    if not id_origem:
        log.error(f"Slug de origem '{slug_origem}' não encontrado. Encerrando.")
        return
    if not id_destino:
        log.error(f"Slug de destino '{slug_destino}' não encontrado. Encerrando.")
        return

    pacotes = listar_pacotes(id_origem)
    if not pacotes:
        log.warning("Nenhum pacote encontrado na categoria de origem.")
        return

    sucesso = falha = 0
    for i, p in enumerate(pacotes, 1):
        pid  = p.get("id")
        nome = p.get("name") or str(pid)
        log.info(f"[{i}/{len(pacotes)}] {nome} (id={pid})")
        if patch_pacote(pid, {"category_id": id_destino}):
            log.info("  ✓ Migrado"); sucesso += 1
        else:
            falha += 1
        time.sleep(DELAY_ENTRE_REQUESTS)

    log.info("=" * 55)
    log.info(f"  CONCLUÍDO: {sucesso} migrado(s), {falha} falha(s)")
    log.info("=" * 55)

# ══════════════════════════════════════════════════════
#  SCRIPT 2 — ATUALIZAR PREÇO COMPARATIVO (+70%)
# ══════════════════════════════════════════════════════

def atualizar_preco_comparativo(slugs=None):
    """Atualiza o preço comparativo de todos os pacotes (e variações) para +70% do preço atual."""
    log.info("=" * 55)
    log.info("  ATUALIZAÇÃO DE PREÇO COMPARATIVO (+70%)")
    log.info("=" * 55)

    categorias = buscar_todas_categorias()

    # Se não passar slugs, usa todas as categorias
    if not slugs:
        slugs = [c.get("slug") for c in categorias if c.get("slug")]

    todos_pacotes = {}
    for slug in slugs:
        cat_id = buscar_id_por_slug(slug, categorias)
        if not cat_id:
            log.warning(f"Slug '{slug}' não encontrado, pulando...")
            continue
        log.info(f"Buscando pacotes de '{slug}' (id={cat_id})...")
        for p in listar_pacotes(cat_id):
            todos_pacotes[p.get("id")] = p
        time.sleep(1)

    log.info(f"Total único de pacotes: {len(todos_pacotes)}")

    sucesso = falha = 0
    lista = list(todos_pacotes.values())

    for i, p in enumerate(lista, 1):
        pid   = p.get("id")
        nome  = p.get("name") or str(pid)
        preco = p.get("price")

        completo  = buscar_pacote_completo(pid)
        variacoes = completo.get("variations", []) if completo else []

        if variacoes:
            log.info(f"[{i}/{len(lista)}] {nome} — {len(variacoes)} variação(ões)")
            for v in variacoes:
                vid    = v.get("id")
                vnome  = v.get("name") or str(vid)
                vpreco = v.get("price")
                if not vpreco or vpreco == 0:
                    log.warning(f"  Variação '{vnome}': sem preço, pulando")
                    continue
                novo = round(vpreco * 1.70, 2)
                log.info(f"  {vnome} — R${vpreco} → R${novo}")
                if patch_pacote(vid, {"compare_at_price": novo}):
                    log.info(f"    ✓ OK"); sucesso += 1
                else:
                    falha += 1
                time.sleep(DELAY_ENTRE_REQUESTS)
        else:
            if not preco or preco == 0:
                log.warning(f"[{i}/{len(lista)}] {nome}: sem preço, pulando")
                continue
            novo = round(preco * 1.70, 2)
            log.info(f"[{i}/{len(lista)}] {nome} — R${preco} → R${novo}")
            if patch_pacote(pid, {"compare_at_price": novo}):
                log.info(f"  ✓ OK"); sucesso += 1
            else:
                falha += 1
            time.sleep(DELAY_ENTRE_REQUESTS)

    log.info("=" * 55)
    log.info(f"  CONCLUÍDO: {sucesso} atualizado(s), {falha} falha(s)")
    log.info("=" * 55)

# ══════════════════════════════════════════════════════
#  MENU PRINCIPAL
# ══════════════════════════════════════════════════════

def menu():
    verificar_creditos()
    print("Escolha uma opção:")
    print("  1 - Migrar produtos de categoria")
    print("  2 - Atualizar preço comparativo (+70%)")
    print("  0 - Sair")
    opcao = input("\nOpção: ").strip()

    if opcao == "1":
        origem  = input("Slug da categoria ORIGEM : ").strip()
        destino = input("Slug da categoria DESTINO: ").strip()
        migrar_categoria(origem, destino)

    elif opcao == "2":
        print("\nDigite os slugs das categorias separados por vírgula")
        print("(deixe em branco para processar TODAS as categorias)")
        entrada = input("Slugs: ").strip()
        slugs = [s.strip() for s in entrada.split(",")] if entrada else None
        atualizar_preco_comparativo(slugs)

    elif opcao == "0":
        print("Saindo...")
        sys.exit(0)
    else:
        print("Opção inválida!")
        menu()

if __name__ == "__main__":
    menu()
